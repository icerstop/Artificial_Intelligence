import torch
import torch.nn as nn
import torch.nn.functional as F
import pytorch_lightning as pl
import torchvision.utils as vutils
import math
import psutil
import os


class VAE(pl.LightningModule):
    """Variational Autoencoder for MNIST digits."""

    def __init__(
        self,
        input_dim: int = 784,
        hidden_dim: int = 256,
        latent_dim: int = 16,
        lr: float = 1e-3,
        optimizer_name: str = "adam",
        weight_decay: float = 1e-5,
        kl_weight: float = 1.0,
    ):
        super().__init__()
        self.save_hyperparameters()

        self.kl_weight = kl_weight
        self.lr = lr
        self.optimizer_name = optimizer_name
        self.weight_decay = weight_decay

        # Encoder
        self.encoder = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.ReLU(),
        )
        self.fc_mu = nn.Linear(hidden_dim // 2, latent_dim)
        self.fc_log_var = nn.Linear(hidden_dim // 2, latent_dim)

        # Decoder
        self.decoder = nn.Sequential(
            nn.Linear(latent_dim, hidden_dim // 2),
            nn.ReLU(),
            nn.Linear(hidden_dim // 2, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, input_dim),
            nn.Sigmoid(),
        )

    def encode(self, x):
        """Encode input to mu and log_var."""
        h = self.encoder(x)
        mu = self.fc_mu(h)
        log_var = self.fc_log_var(h)
        return mu, log_var

    def reparameterize(self, mu, log_var):
        """Reparameterization trick: z = mu + std * eps."""
        std = torch.exp(0.5 * log_var)
        eps = torch.randn_like(std)
        return mu + std * eps

    def decode(self, z):
        """Decode latent vector to reconstruction."""
        return self.decoder(z)

    def forward(self, x):
        """Full forward pass."""
        # Flatten
        x_flat = x.view(x.size(0), -1)
        mu, log_var = self.encode(x_flat)
        z = self.reparameterize(mu, log_var)
        x_recon = self.decode(z)
        return x_recon, mu, log_var

    def _compute_loss(self, batch):
        """Compute VAE loss = reconstruction + KL divergence.

        Both terms use: sum over dimensions, mean over batch.
        This ensures recon (784 pixels) and KL (latent dims) are on
        the same scale — critical to avoid posterior collapse.
        """
        x, _ = batch  # ignore labels
        x_recon, mu, log_var = self(x)
        x_flat = x.view(x.size(0), -1)

        # Reconstruction loss (BCE): sum over 784 pixels, mean over batch
        recon_loss = F.binary_cross_entropy(
            x_recon, x_flat, reduction="sum"
        ) / x.size(0)

        # KL divergence: sum over latent dims, mean over batch
        kl_loss = -0.5 * torch.mean(
            torch.sum(1 + log_var - mu.pow(2) - log_var.exp(), dim=1)
        )

        total_loss = recon_loss + self.kl_weight * kl_loss
        return total_loss, recon_loss, kl_loss

    def training_step(self, batch, batch_idx):
        total_loss, recon_loss, kl_loss = self._compute_loss(batch)

        # Per-step metrics for finer-grained loss curves
        self.log("train_loss_step", total_loss, on_step=True, on_epoch=False)
        self.log("train_recon_loss_step", recon_loss, on_step=True, on_epoch=False)
        self.log("train_kl_loss_step", kl_loss, on_step=True, on_epoch=False)

        # Log learning rate
        opt = self.optimizers()
        if opt is not None:
            current_lr = opt.param_groups[0]["lr"]
            self.log("lr", current_lr, on_step=True, on_epoch=False)

        return total_loss

    def validation_step(self, batch, batch_idx):
        total_loss, recon_loss, kl_loss = self._compute_loss(batch)

        self.log("val_loss", total_loss, on_step=False, on_epoch=True, prog_bar=True)
        self.log("val_recon_loss", recon_loss, on_step=False, on_epoch=True)
        self.log("val_kl_loss", kl_loss, on_step=False, on_epoch=True)

        return total_loss
    
    def on_before_optimizer_step(self, optimizer):
        """Logowanie gradientów tuż przed krokiem optymalizatora."""
        if self.logger is None:
            return

        tb = self.logger.experiment
        step = self.global_step 

        if step % 100 != 0:
            return

        total_norm = 0.0
        layer_norms = {}
        max_grad = 0.0

        for name, param in self.named_parameters():
            if param.requires_grad and param.grad is not None:
                tb.add_histogram(f"gradients/{name}", param.grad, step)

                pnorm = param.grad.data.norm(2).item()
                total_norm += pnorm ** 2
                max_grad = max(max_grad, param.grad.data.abs().max().item())
                
                module = name.split(".")[0]
                layer_norms[module] = layer_norms.get(module, 0.0) + pnorm ** 2

        total_norm = math.sqrt(total_norm)
        tb.add_scalar("grad/total_norm", total_norm, step)
        tb.add_scalar("grad/max_value", max_grad, step)

        norms_list = []
        for module, norm_sq in layer_norms.items():
            norm = math.sqrt(norm_sq)
            tb.add_scalar(f"grad_norm/{module}", norm, step)
            norms_list.append(norm)

        if len(norms_list) >= 2:
            ratio = max(norms_list) / (min(norms_list) + 1e-8)
            tb.add_scalar("grad/layer_ratio", ratio, step)

    def on_validation_epoch_end(self):
        """Log sample reconstructions, generated images, histograms, and latent stats."""
        if self.logger is None:
            return

        tb = self.logger.experiment
        epoch = self.current_epoch

        z = torch.randn(16, self.hparams.latent_dim, device=self.device)
        samples = self.decode(z).view(-1, 1, 28, 28)
        grid = vutils.make_grid(samples, nrow=4, normalize=True)
        tb.add_image("generated_samples", grid, epoch)


        val_dl = self.trainer.val_dataloaders
        if val_dl is not None:
            sample_batch = next(iter(val_dl))
            x_sample, _ = sample_batch
            x_sample = x_sample[:8].to(self.device)
            with torch.no_grad():
                x_recon, mu, log_var = self(x_sample)
            x_recon_img = x_recon.view(-1, 1, 28, 28)
            x_sample_img = x_sample.view(-1, 1, 28, 28)
            # Top row: inputs, bottom row: reconstructions
            comparison = torch.cat(
                [x_sample_img, x_recon_img], dim=0
            )
            grid_recon = vutils.make_grid(
                comparison, nrow=8, normalize=True
            )
            tb.add_image("reconstructions_top_input_bottom_output", grid_recon, epoch)

            #(posterior collapse detection)
            tb.add_scalar("latent/mu_mean", mu.mean().item(), epoch)
            tb.add_scalar("latent/mu_std", mu.std().item(), epoch)
            sigma = torch.exp(0.5 * log_var)
            tb.add_scalar("latent/sigma_mean", sigma.mean().item(), epoch)
            tb.add_scalar("latent/sigma_std", sigma.std().item(), epoch)
            # Active units: dimensions where sigma < 0.95
            active_units = (sigma.mean(dim=0) < 0.95).float().sum().item()
            tb.add_scalar("latent/active_units", active_units, epoch)

        # Weight & bias histograms
        for name, param in self.named_parameters():
            if param.requires_grad:
                tb.add_histogram(f"weights/{name}", param.data, epoch)
                if param.grad is not None:
                    tb.add_histogram(f"gradients/{name}", param.grad, epoch)


        #  System resource usage 
        process = psutil.Process(os.getpid())
        tb.add_scalar("system/cpu_percent", psutil.cpu_percent(), epoch)
        tb.add_scalar("system/ram_percent", psutil.virtual_memory().percent, epoch)
        tb.add_scalar("system/rss_mb", process.memory_info().rss / 1024 / 1024, epoch)

    def on_train_end(self):
        """Log hyperparameters + final metrics to TensorBoard HPARAMS tab."""
        if self.logger is None:
            return

        metrics = self.trainer.callback_metrics
        tb = self.logger.experiment

        hparams = {
            "hidden_dim": self.hparams.hidden_dim,
            "latent_dim": self.hparams.latent_dim,
            "lr": self.hparams.lr,
            "optimizer": self.optimizer_name,
            "weight_decay": self.weight_decay,
            "kl_weight": self.kl_weight,
            "input_dim": self.hparams.input_dim,
        }

        final_metrics = {
            "hparam/val_loss": metrics.get("val_loss", 0),
            "hparam/val_recon_loss": metrics.get("val_recon_loss", 0),
            "hparam/val_kl_loss": metrics.get("val_kl_loss", 0),
        }

        tb.add_hparams(hparams, final_metrics)

    def configure_optimizers(self):
        if self.optimizer_name == "adam":
            optimizer = torch.optim.Adam(
                self.parameters(), lr=self.lr, weight_decay=self.weight_decay
            )
        elif self.optimizer_name == "adamw":
            optimizer = torch.optim.AdamW(
                self.parameters(), lr=self.lr, weight_decay=self.weight_decay
            )
        elif self.optimizer_name == "sgd":
            optimizer = torch.optim.SGD(
                self.parameters(),
                lr=self.lr,
                momentum=0.9,
                weight_decay=self.weight_decay,
            )
        else:
            raise ValueError(f"Unknown optimizer: {self.optimizer_name}")

        scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
            optimizer, mode="min", factor=0.5, patience=5
        )

        return {
            "optimizer": optimizer,
            "lr_scheduler": {
                "scheduler": scheduler,
                "monitor": "val_loss",
            },
        }

"""
Optuna hyperparameter optimization for VAE on MNIST.

Optimized parameters:
    - latent_dim: [2, 4, 8, 16, 32]
    - hidden_dim: [128, 256, 512]
    - lr: log-uniform [1e-5, 1e-2]
    - batch_size: [32, 64, 128]
    - optimizer: ["adam", "adamw", "sgd"]
    - kl_weight: [0.1, 0.5, 1.0, 2.0]

Usage:
    python src/optimize.py

View logs:
    tensorboard --logdir tb_logs
"""

import optuna
from optuna.integration import PyTorchLightningPruningCallback

import pytorch_lightning as pl
from pytorch_lightning.callbacks import EarlyStopping
from pytorch_lightning.loggers import TensorBoardLogger

from data_module import MNISTDataModule
from model import VAE


def objective(trial: optuna.Trial) -> float:
    """Single Optuna trial — train VAE with suggested hyperparameters."""

    #  Suggest hyperparameters 
    latent_dim = trial.suggest_categorical("latent_dim", [2, 4, 8, 16, 32])
    hidden_dim = trial.suggest_categorical("hidden_dim", [128, 256, 512])
    lr = trial.suggest_float("lr", 1e-5, 1e-2, log=True)
    batch_size = trial.suggest_categorical("batch_size", [32, 64, 128])
    optimizer_name = trial.suggest_categorical("optimizer", ["adam", "adamw", "sgd"])
    kl_weight = trial.suggest_categorical("kl_weight", [0.1, 0.5, 1.0, 2.0])

    #  DataModule 
    dm = MNISTDataModule(
        data_dir="data",
        batch_size=batch_size,
        num_workers=0,
    )

    #  Model 
    model = VAE(
        hidden_dim=hidden_dim,
        latent_dim=latent_dim,
        lr=lr,
        optimizer_name=optimizer_name,
        kl_weight=kl_weight,
    )

    #  Logger (separate directory per trial) 
    logger = TensorBoardLogger(
        save_dir="tb_logs",
        name="optuna_vae",
        version=f"trial_{trial.number}",
    )

    #  Callbacks 
    early_stop = EarlyStopping(
        monitor="val_loss",
        patience=3,
        mode="min",
    )

    pruning_callback = PyTorchLightningPruningCallback(
        trial, monitor="val_loss"
    )

    #  Trainer 
    trainer = pl.Trainer(
        max_epochs=15,
        accelerator="cpu",
        logger=logger,
        callbacks=[early_stop, pruning_callback],
        log_every_n_steps=50,
        enable_progress_bar=False,
        enable_model_summary=False,
    )

    #  Train 
    trainer.fit(model, datamodule=dm)

    return trainer.callback_metrics["val_loss"].item()


def main():
    #  Create study 
    study = optuna.create_study(
        direction="minimize",
        study_name="vae_mnist_optimization",
        pruner=optuna.pruners.MedianPruner(
            n_startup_trials=3,
            n_warmup_steps=3,
        ),
    )

    #  Run optimization 
    print("=" * 60)
    print("OPTUNA HYPERPARAMETER OPTIMIZATION")
    print("=" * 60)

    study.optimize(objective, n_trials=20, show_progress_bar=True)

    #  Results 
    print("\n" + "=" * 60)
    print("OPTIMIZATION RESULTS")
    print("=" * 60)

    print(f"\nBest trial: #{study.best_trial.number}")
    print(f"Best val_loss: {study.best_trial.value:.4f}")
    print(f"\nBest hyperparameters:")
    for key, value in study.best_trial.params.items():
        print(f"  {key}: {value}")

    #  Print top 5 trials 
    print(f"\nTop 5 trials:")
    sorted_trials = sorted(study.trials, key=lambda t: t.value if t.value is not None else float("inf"))
    for i, trial in enumerate(sorted_trials[:5]):
        print(f"  #{trial.number}: val_loss={trial.value:.4f} | {trial.params}")

    print(f"\nView TensorBoard logs: tensorboard --logdir tb_logs")


if __name__ == "__main__":
    main()

import pytorch_lightning as pl
from pytorch_lightning.callbacks import EarlyStopping, ModelCheckpoint, LearningRateMonitor
from pytorch_lightning.loggers import TensorBoardLogger

from data_module import MNISTDataModule
from model import VAE


def main():
    #  DataModule 
    dm = MNISTDataModule(
        data_dir="data",
        batch_size=128,
        num_workers=4,
        persistent_workers=True
    )

    #  Model 
    model = VAE(
        hidden_dim=256,
        latent_dim=16,
        lr=5e-4,
        optimizer_name="adamw",
        kl_weight=2,
    )

    #  Logger 
    logger = TensorBoardLogger(
        save_dir="tb_logs",
        name="vae_mnist",
    )

    #  Callbacks 
    early_stop = EarlyStopping(
        monitor="val_loss",
        patience=5,
        mode="min",
        verbose=True,
    )

    checkpoint = ModelCheckpoint(
        monitor="val_loss",
        mode="min",
        save_top_k=1,
        filename="best-vae-{epoch:02d}-{val_loss:.4f}",
        verbose=True,
    )

    lr_monitor = LearningRateMonitor(logging_interval="step")

    #  Trainer 
    trainer = pl.Trainer(
        max_epochs=30,
        accelerator="auto",
        logger=logger,
        callbacks=[early_stop, checkpoint, lr_monitor],
        log_every_n_steps=50,
    )

    #  Train 
    trainer.fit(model, datamodule=dm)

    print(f"\nBest model: {checkpoint.best_model_path}")
    print(f"Best val_loss: {checkpoint.best_model_score:.4f}")
    print(f"\nView TensorBoard logs: tensorboard --logdir tb_logs")


if __name__ == "__main__":
    main()

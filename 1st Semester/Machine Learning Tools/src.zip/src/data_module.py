import pytorch_lightning as pl
from torch.utils.data import DataLoader, random_split
from torchvision import transforms
from torchvision.datasets import MNIST


class MNISTDataModule(pl.LightningDataModule):
    """DataModule for MNIST digit dataset."""

    def __init__(
        self,
        data_dir: str = "data",
        batch_size: int = 64,
        num_workers: int = 0,
        val_split: float = 0.1,
        persistent_workers=True
    ):
        super().__init__()
        self.save_hyperparameters()

        self.data_dir = data_dir
        self.batch_size = batch_size
        self.num_workers = num_workers
        self.val_split = val_split
        self.persistent_workers = persistent_workers

        self.transform = transforms.Compose(
            [
                transforms.ToTensor(),
            ]
        )

    def prepare_data(self):
        """Download MNIST."""
        MNIST(self.data_dir, train=True, download=True)
        MNIST(self.data_dir, train=False, download=True)

    def setup(self, stage=None):
        """Create train/val/test splits."""
        if stage == "fit" or stage is None:
            full_train = MNIST(
                self.data_dir, train=True, transform=self.transform
            )
            val_size = int(len(full_train) * self.val_split)
            train_size = len(full_train) - val_size
            self.train_dataset, self.val_dataset = random_split(
                full_train, [train_size, val_size]
            )

        if stage == "test" or stage is None:
            self.test_dataset = MNIST(
                self.data_dir, train=False, transform=self.transform
            )

    def train_dataloader(self):
        return DataLoader(
            self.train_dataset,
            batch_size=self.batch_size,
            shuffle=True,
            num_workers=self.num_workers,
            persistent_workers=self.persistent_workers
        )

    def val_dataloader(self):
        return DataLoader(
            self.val_dataset,
            batch_size=self.batch_size,
            shuffle=False,
            num_workers=self.num_workers,
            persistent_workers=self.persistent_workers
        )

    def test_dataloader(self):
        return DataLoader(
            self.test_dataset,
            batch_size=self.batch_size,
            shuffle=False,
            num_workers=self.num_workers,
        )
